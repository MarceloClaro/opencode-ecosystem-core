#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gerador do Módulo 10 — Catálogo Completo de Agentes e Subagentes.
Lê opencode.json + agents/catalog/*.md e produz mod-10-catalogo.tex
com uma ficha (elemento) por agente, agrupado por categoria.

Uso:  python3 gen_mod10.py   (a partir de livro-core/ ou de raiz do repo)
"""
import json, glob, os, re, sys

ROOT = os.environ.get("CORE_ROOT", os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
OUT = os.path.join(os.path.dirname(__file__), "mod-10-catalogo.tex")


def esc(t):
    if t is None:
        return ""
    t = str(t)
    t = t.replace("\\", r"\textbackslash{}")
    t = t.replace("{", r"\{").replace("}", r"\}")
    t = t.replace("#", r"\#").replace("&", r"\&")
    t = t.replace("$", r"\$").replace("%", r"\%").replace("_", r"\_")
    t = t.replace("^", r"\^{}").replace("~", r"\~{}")
    return t


def frontmatter(path):
    txt = open(path, encoding="utf-8").read()
    # Tolerante a cabecalho de comentario HTML antes da cerca de frontmatter
    # (padrao dos cards de agents/catalog/*.md). Sem re.M o ^ ancorava apenas
    # no inicio do arquivo e 40 cards eram silenciosamente descartados.
    block = re.search(r"^---[ \t]*\n(.*?)\n---[ \t]*$", txt, re.S | re.M)
    if not block:
        return {}
    data = {}
    for m in re.finditer(r"^([A-Za-z_][\w-]*):[ \t]*(.+)$", block.group(1), re.M):
        data[m.group(1)] = m.group(2).strip().strip("'\"")
    return data


# --- R618: reconciliacao catalogo <-> runtime -------------------------------
# O frontmatter dos cards usa o NOME HUMANO ("Medico Cardiologista"), enquanto o
# opencode.json registra o SLUG kebab-case ("medico-cardiologista"). Comparar os
# dois textos literalmente produzia 39 falsos "nao registrados" (SPEC-935-R618).
import difflib
import unicodedata

# Casos em que nem o slug nem a similaridade resolvem: declarados, nunca adivinhados.
ALIASES = {
    "Synthetic University — Orquestrador Acadêmico Transversal": "university_synthetic",
    "Agente Reversa: Agent Forum / Debate Moderator": "reversa-agent-forum",
    "Agente Reversa: Document IR Report Pipeline": "reversa-document-ir",
    "Agente Reversa: Process Lifecycle Manager": "reversa-process-lifecycle",
    "Catálogo de Skills Cloud (Antigravity Backup)": "skills-cloud-antigravity",
    "Cloud SQL PostgreSQL Specialist": "cloud-sql-postgres-specialist",
    "Cloud SQL SQL Server Specialist": "cloud-sql-sqlserver-specialist",
    "Haystack RAG Specialist": "haystack-rag",
    "OpenCopywriter": "copywriter",
    "OpenTechnicalWriter": "technical-writer",
    "PyPISearcher": "pypi-searcher",
    "MasterOrchestrator": "master-orchestrator",
    "StageOrchestrator": "stage-orchestrator",
    "AntigravityOrchestrator": "antigravity-orchestrator",
    "ContextScout": "contextscout",
    "Eval Runner": "eval-runner",
    "Image Specialist": "image-specialist",
    "Nano Orchestrator": "nano-orchestrator",
}

# Agentes registrados no runtime por definicao propria (sem card), declarados
# explicitamente: sao os unicos que podem ficar fora de agents/catalog/.
INLINE_DECLARADOS = frozenset()

SIMILARIDADE_MINIMA = 0.55


def _slug(s):
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode()
    return re.sub(r"-+", "-", re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-").lower())


def _tokens(s):
    return set(t for t in _slug(s).split("-") if len(t) > 2)


def carregar_cards(root):
    """Nome do frontmatter -> frontmatter, de todos os agents/catalog/*.md."""
    out = {}
    for f in sorted(glob.glob(os.path.join(str(root), "agents", "catalog", "*.md"))):
        fm = frontmatter(f)
        fm["_file"] = f
        if fm.get("name"):
            out[fm["name"]] = fm
    return out


def reconciliar(cards, runtime):
    """Mapeia nome-humano da ficha -> chave de agente no runtime.

    Ordem: nome exato -> alias declarado -> slug exato -> similaridade. A
    similaridade e apenas um ultimo recurso; os casos que dependem dela estao
    cobertos por ALIASES para que o resultado nao dependa de heuristica.
    """
    pares = {}
    for nome in sorted(cards):
        if nome in runtime:
            pares[nome] = nome
            continue
        if nome in ALIASES and ALIASES[nome] in runtime:
            pares[nome] = ALIASES[nome]
            continue
        s = _slug(nome)
        exato = [r for r in runtime if _slug(r) == s]
        if exato:
            pares[nome] = exato[0]
            continue
        melhor, score = None, 0.0
        for r in runtime:
            q = difflib.SequenceMatcher(None, s, _slug(r)).ratio()
            inter = len(_tokens(nome) & _tokens(r))
            uni = len(_tokens(nome) | _tokens(r))
            j = inter / uni if uni else 0.0
            if max(q, j) > score:
                melhor, score = r, max(q, j)
        if melhor and score >= SIMILARIDADE_MINIMA:
            pares[nome] = melhor
    return pares


def nao_registrados(cards, runtime):
    return sorted(n for n in cards if n not in reconciliar(cards, runtime))


def main():
    cfg = json.load(open(os.path.join(ROOT, "opencode.json"), encoding="utf-8"))
    agents = cfg.get("agent", {})
    catalog = carregar_cards(ROOT)
    # R618: reconciliacao por convencao de nome (slug) em vez de igualdade textual
    pares = reconciliar(catalog, agents)
    nao_reg = [n for n in sorted(catalog) if n not in pares]
    runtime_sem_ficha = sorted(set(agents) - set(pares.values()) - set(INLINE_DECLARADOS))

    # metadados por agente (fonte + descricao)
    meta = {}
    for name, f in catalog.items():
        meta[name] = {
            "file": f["_file"].split("agents/catalog/")[-1],
            "desc": f.get("description", ""),
            "category": f.get("category", "ferramental"),
            "atype": f.get("type", "specialist"),
            "ver": f.get("version", ""),
        }

    inline = 0
    for name, v in agents.items():
        if name in INLINE_DECLARADOS:
            prompt = v.get("prompt", "")
            meta[name] = {
                "file": "inline (opencode.json)" if prompt else "inline",
                "desc": v.get("description", ""),
                "category": "orquestracao",
                "atype": v.get("mode", "agent"),
                "ver": "",
            }
            inline += 1

    order = ["orchestration", "academic", "research", "audit", "legal", "data",
             "inference", "engineering", "testing", "literary", "curation-agent",
             "integration", "mira-agent", "maswos-agent", "utility"]
    cats = {}
    for name, m in meta.items():
        cats.setdefault(m["category"], []).append(name)
    for k in list(cats):
        cats[k].sort(key=lambda n: n.lower())

    # Nenhuma ficha pode ser descartada: categorias fora da ordem canonica
    # entram ao final, em vez de sumirem silenciosamente do corpo do capitulo.
    emit_order = [c for c in order if c in cats]
    emit_order += sorted(c for c in cats if c not in order)

    # Numeros derivados por contagem literal (nunca fixos no gerador).
    # R618: n_fichas e o numero de AGENTES (1:1 com o runtime), e nao a soma
    # bruta de nomes — antes, alias de slug contavam duas vezes e inflavam o
    # total para 255 com apenas 216 agentes reais.
    n_agents = len(agents)
    n_cards = len(catalog)
    n_prim = sum(1 for v in agents.values() if v.get("mode") == "primary")
    n_sub = n_agents - n_prim
    n_fichas = n_agents
    n_nao_registrados = len(nao_reg)
    n_runtime_sem_ficha = len(runtime_sem_ficha)

    fd = []
    fd.append("% ============================================================")
    fd.append("%  MÓDULO 10 — Catálogo Completo de Agentes e Subagentes")
    fd.append("%  ARQUIVO GERADO — não editar à mão. Rode: python3 gen_mod10.py")
    fd.append("% ============================================================")
    fd.append(f"\\chapter{{Catálogo Completo — {n_fichas} Fichas de Agente "
              f"({n_fichas} registradas no runtime)}}")
    fd.append("")
    fd.append("\\begin{resultado}")
    fd.append(f"O \\pth{{opencode.json}} registra \\textbf{{{n_agents}}} agentes "
              f"({n_prim} orquestrador, {n_sub} subagentes), e o acervo "
              f"\\pth{{agents/catalog/}} traz \\textbf{{{n_cards}}} fichas. "
              f"Cada agente tem exatamente uma ficha e cada ficha um agente: "
              f"a cobertura documental é \\textbf{{1:1}} "
              f"({n_nao_registrados} fichas sem registro, "
              f"{n_runtime_sem_ficha} agentes sem ficha). As {n_fichas} fichas "
              f"abaixo são geradas deterministicamente por \\pth{{gen\\_mod10.py}} "
              f"e agrupam-se por categoria.")
    fd.append("\\end{resultado}")
    fd.append("")
    fd.append("\\begin{aviso}")
    fd.append(f"\\textbf{{Convenção de nomes (verificada em 29/09/2026, "
              f"SPEC-935-R618).}} O \\pth{{frontmatter}} de cada card usa o "
              f"\\emph{{nome humano}} (ex.: \\emph{{Cloud SQL PostgreSQL "
              f"Specialist}}), enquanto \\pth{{opencode.json}} registra o "
              f"\\emph{{slug}} em kebab-case (ex.: \\cod{{cloud-sql-postgres-"
              f"specialist}}). Uma versão anterior deste capítulo comparava os dois "
              f"textos literalmente e reportava trinta e nove fichas como não registradas — "
              f"falso positivo de convenção, não lacuna de runtime: reconciliadas "
              f"pelo slug e por alias declarado, todas as {n_cards} fichas estão "
              f"registradas. Ficha documentada ainda $\\neq$ agente testado: "
              f"registrar não prova que o agente funcione.")
    fd.append("\\end{aviso}")
    fd.append("")
    # ---- N-10 (R618): todos os numeros sao DERIVADOS, nunca fixos ----
    cats_sorted = sorted(cats.items(), key=lambda kv: -len(kv[1]))
    l1, l2 = len(cats_sorted[0][1]), len(cats_sorted[1][1])
    n_cat = len(cats)
    top2 = l1 + l2
    pct_top2 = (f"{100.0 * top2 / n_agents:.1f}").replace(".", ",")
    media_cat = (f"{n_agents / n_cat:.1f}").replace(".", ",")
    exatos = sum(1 for n in catalog if n in agents)
    naive_falta = n_cards - exatos
    alias_hits = sum(1 for n in catalog
                      if n not in agents and n in ALIASES and ALIASES[n] in agents)
    slug_hits = naive_falta - alias_hits
    cob_ingenua_pct = round(100.0 * exatos / n_agents)

    fd.append("\\begin{processo}")
    fd.append("GATILHO. o leitor quer saber se o runtime entrega o que o acervo "
              "promete, ou se documentacao e disponibilidade sao coisas distintas.")
    fd.append("ROTA. reconciliar ficha contra registro antes de contar inventario.")
    fd.append("FUNCAO. transformar o catalogo enumerativo em um teste de "
              "consistencia executavel, e nao em uma lista de nomes.")
    fd.append("\\end{processo}")
    fd.append("")
    fd.append("\\section[Leitura guiada]{Leitura guiada — Módulo 10: "
              "o catálogo como teste de consistência}")
    fd.append("")
    fd.append("\\begin{descricao}")
    fd.append(f"\\textbf{{O fenômeno.}} Um capítulo que enumera {n_agents} agentes "
              "produz a impressão de catálogo fiel. Mas a enumeração é a forma mais "
              "fácil de mascarar um erro de reconciliação: se o procedimento de "
              "contagem compara o nome humano do card com o slug do runtime, a lista "
              "parece cheia de agentes faltantes que não faltam. Foi exatamente o que "
              "aconteceu: o capítulo afirmava não estarem registradas fichas que "
              "estavam todas registradas, apenas sob outra convenção de nome.")
    fd.append("\\end{descricao}")
    fd.append("")
    fd.append("\\begin{definicao}")
    fd.append("\\textbf{Grandezas e definições.}\\par")
    fd.append("(1) \\emph{Ficha}: registro documental em \\pth{agents/catalog/}, "
              "identificado pelo \\emph{nome humano} no frontmatter.\\par")
    fd.append("(2) \\emph{Agente registrado}: entrada na chave \\pth{agent} do "
              "\\pth{opencode.json}, identificada pelo \\emph{slug} em "
              "kebab-case.\\par")
    fd.append("(3) \\emph{Reconciliação}: correspondência bijetiva entre ficha e "
              "agente, resolvida por nome exato, alias declarado ou slug.\\par")
    fd.append("(4) \\emph{Cobertura documental}: a razão entre o número de agentes "
              "com ficha e o número de agentes registrados.\\par")
    fd.append("(5) \\emph{Falso positivo de convenção}: contagem que reporta "
              "ausência onde há apenas diferença de grafia entre as duas colunas.")
    fd.append("\\end{definicao}")
    fd.append("")
    fd.append("\\begin{metodo}")
    fd.append("\\textbf{Dedução passo a passo.} Por que o erro numérico é "
              "inofensivo e o erro de reconciliação não?\\par")
    fd.append("(1) Uma lista de nomes não tem invariante: qualquer contagem produz "
              "um inteiro, e um inteiro plausível é indistinguível de um inteiro "
              "errado.\\par")
    fd.append("(2) Uma reconciliação tem invariante: o conjunto de fichas e o "
              "conjunto de agentes devem ter a mesma cardinalidade, e cada elemento "
              "de um deve ter exatamente um parceiro no outro.\\par")
    fd.append("(3) Sem a convenção de nomes explicitada, a comparação literal entre "
              "duas colunas de nomes mede \\emph{grafia}, não presença.\\par")
    fd.append("(4) A soma bruta de dois conjuntos que se correspondem por alias "
              "conta cada agente duas vezes: o total fica inflado e a discrepância "
              "aparente, quando na verdade inexiste.\\par")
    fd.append("(5) Logo, a contagem correta exige reconciliar antes de somar, e o "
              "resíduo da reconciliação é o número que merece atenção.")
    fd.append("\\end{metodo}")
    fd.append("")
    fd.append("\\begin{resultado}")
    fd.append(f"\\textbf{{Exemplo resolvido.}} Estado medido em 29/09/2026, com "
              f"$N = {n_agents}$ agentes no \\pth{{opencode.json}} e $F = {n_cards}$ "
              f"fichas em \\pth{{agents/catalog/}}.\\par")
    fd.append(f"(1) Contagem ingênua por igualdade textual: ${naive_falta}$ fichas "
              f"sem correspondência exata, o que sugeriria cobertura de "
              f"$\\frac{{{exatos}}}{{{n_agents}}} \\approx {cob_ingenua_pct}\\%$ "
              f"— número plausível, e por isso mesmo perigoso.\\par")
    fd.append(f"(2) Reconciliação por slug: os ${naive_falta}$ casos se resolvem em "
              f"${slug_hits}$ por equivalência direta de slug e em ${alias_hits}$ por "
              f"alias declarado (ex.: \\emph{{Synthetic University — Orquestrador "
              f"Acadêmico Transversal}} $\\to$ \\cod{{university_synthetic}}).\\par")
    fd.append(f"(3) Resíduo: ${naive_falta} - {slug_hits} - {alias_hits} = 0$ fichas "
              f"sem agente; e ${n_runtime_sem_ficha}$ agentes sem ficha.\\par")
    fd.append(f"(4) Cobertura documental correta: "
              f"$\\frac{{{n_agents}}}{{{n_agents}}} = 1 = 100\\%$.\\par")
    fd.append("(5) Leitura correta do número verdadeiro: uma versão anterior somava "
              "os dois acervos como se fossem disjuntos e obtinha um total maior que "
              "o número real de agentes — supercontagem devida a aliases contados em "
              "duplicidade.")
    fd.append("\\end{resultado}")
    fd.append("")
    fd.append("\\begin{resultado}")
    fd.append(f"\\textbf{{Ordem de grandeza e verificação.}} A cobertura de "
              f"$100\\%$ é exata e, ainda assim, diz pouco: as duas maiores "
              f"categorias (${l1}$ e ${l2}$ fichas, de {n_cat} no total) somam "
              f"$\\frac{{{top2}}}{{{n_agents}}} \\approx {pct_top2}\\%$, de modo que "
              f"a média por categoria (${n_agents}/{n_cat} \\approx {media_cat}$) "
              f"descreve mal a distribuição — o mesmo mecanismo de concentração que "
              f"oculta o desequilíbrio no Módulo 8. \\emph{{Verifique você mesmo:}} "
              f"rode \\cod{{python3 gen_mod10.py}} e confira quantos elementos são "
              f"emitidos; alterar o \\pth{{opencode.json}} e reexecutar deve mover "
              f"esse número na mesma medida.")
    fd.append("\\end{resultado}")
    fd.append("")
    fd.append("\\begin{aviso}")
    fd.append("\\textbf{Limite de validade.} Reconciliação é consistência "
              "declarativa, não evidência funcional: um agente registrado e "
              "documentado pode ainda estar quebrado, jamais invocado ou sem "
              "permissão adequada. O resultado $100\\%$ atesta que nome e documento "
              "batem, não que o agente funcione: atestar comportamento é o gate de "
              "teste, descrito no Módulo 4.")
    fd.append("\\end{aviso}")
    fd.append("")
    fd.append("\\begin{resultado}")
    fd.append("\\textbf{Exercícios.} (1) Acrescente um agente fictício ao "
              "\\pth{opencode.json} sem card correspondente e calcule a cobertura "
              "resultante. (2) Remova o alias de \\emph{Synthetic University} no "
              "gerador e observe o teste de reconciliação falhar. (3) Explique, em "
              "uma frase, por que \\emph{inventário completo} e "
              "\\emph{inventário correto} são propriedades diferentes.")
    fd.append("\\end{resultado}")
    fd.append("")
    fd.append("\\section{Panorama por categoria}")
    fd.append("")
    fd.append("\\begin{resultado}")
    fd.append("Contagem por categoria (ordem decrescente de fichas):\\par")
    fd.append("\\smallskip")
    fd.append("{\\footnotesize")
    fd.append("\\begin{tabularx}{\\textwidth}{lrX}")
    fd.append("\\toprule")
    fd.append("Categoria & Fichas & Exemplo de agentes \\\\")
    fd.append("\\midrule")
    for cat in sorted(cats, key=lambda c: -len(cats[c])):
        ex = ", ".join(cats[cat][:3])
        fd.append(f"{esc(cat)} & {len(cats[cat])} & {esc(ex)} \\\\")
    fd.append("\\bottomrule")
    fd.append("\\end{tabularx}\\par}")
    fd.append("\\end{resultado}")
    fd.append("")

    for cat in emit_order:
        if cat not in cats:
            continue
        fd.append(r"\clearpage")
        fd.append(r"\section{Categoria: " + esc(cat.title()) + f" ({len(cats[cat])} agentes)" + "}")
        fd.append("")
        for name in cats[cat]:
            m = meta[name]
            # Ficha inline (sem card no catalogo) nao tem versao: evita "(v)".
            ver = f" (v{m['ver']})" if m["ver"] else ""
            src = m["file"]
            fd.append(
                f"\\elemento{{{esc(name)}{ver}}}"
                f"{{\\metainfo{{Categoria}}{{{esc(m['category'])}}} \\hfill "
                f"\\metainfo{{Tipo}}{{{esc(m['atype'])}}} \\hfill "
                f"\\metainfo{{Rota}}{{{esc(src)}}}}}"
            )
            fd.append("")
            fd.append("\\begin{descricao}")
            fd.append(esc(m["desc"]) or "\\_sem descrição\\_")
            fd.append("\\end{descricao}")
            fd.append("")
            if name in agents:
                perm = agents[name].get("permission", {})
                mode = agents[name].get("mode", "")
            else:
                perm, mode = {}, ""
            perm_txt = "; ".join(f"{k}: {v}" for k, v in perm.items())
            fd.append("\\begin{arquitetura}")
            fd.append("\\textbf{Modo:} " + esc(mode or "subagent")
                      + (" · \\textbf{Permissões:} " + esc(perm_txt) if perm_txt else ""))
            fd.append("\\end{arquitetura}")
            fd.append("")
    fd.append("% fim do módulo 10 (gerado)")

    open(OUT, "w", encoding="utf-8").write("\n".join(fd) + "\n")
    n_emit = sum(1 for l in fd if l.startswith("\\elemento{"))
    assert n_emit == n_fichas, f"fichas emitidas {n_emit} != {n_fichas}"
    print(f"OK: {n_agents} agentes -> {OUT} "
          f"({n_fichas} fichas em {len(emit_order)} categorias)")


if __name__ == "__main__":
    main()
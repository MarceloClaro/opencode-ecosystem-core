#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gerador do Módulo 10 — Catálogo Completo de Agentes e Subagentes.
Lê opencode.json + agents/catalog/*.md e produz mod-10-catalogo.tex
com uma ficha (elemento) por agente, agrupado por categoria.

Uso:  python3 gen_mod10.py   (a partir de livro-core/ ou de raiz do repo)
"""
import json, glob, os, re, sys

ROOT = os.environ.get("CORE_ROOT", os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
OUT = os.path.join(os.path.dirname(__file__), "mod-10-catalogo.tex")


def esc(t):
    if t is None:
        return ""
    t = str(t)
    t = t.replace("\\", r"\textbackslash{}")
    t = t.replace("{", r"\{").replace("}", r"\}")
    t = t.replace("#", r"\#").replace("&", r"\&")
    t = t.replace("$", r"\$").replace("%", r"\%").replace("_", r"\_")
    t = t.replace("^", r"\^{}").replace("~", r"\~{}")
    return t


def frontmatter(path):
    txt = open(path, encoding="utf-8").read()
    block = re.search(r"^---\n(.*?)\n---", txt, re.S)
    if not block:
        return {}
    data = {}
    for m in re.finditer(r"^(\w+):\s*(.+)$", block.group(1), re.M):
        data[m.group(1)] = m.group(2).strip().strip("'\"")
    return data


def main():
    cfg = json.load(open(os.path.join(ROOT, "opencode.json"), encoding="utf-8"))
    agents = cfg.get("agent", {})
    catalog = {}
    for f in sorted(glob.glob(os.path.join(ROOT, "agents", "catalog", "*.md"))):
        fm = frontmatter(f)
        fm["_file"] = f
        if fm.get("name"):
            catalog[fm["name"]] = fm

    # metadados por agente (fonte + descricao)
    meta = {}
    for name, f in catalog.items():
        src = f.get("skills", "sem skill declarada")
        meta[name] = {
            "file": f["_file"].split("agents/catalog/")[-1],
            "desc": f.get("description", ""),
            "category": f.get("category", "ferramental"),
            "atype": f.get("type", "specialist"),
            "ver": f.get("version", ""),
        }

    inline = 0
    for name, v in agents.items():
        if name not in meta:
            prompt = v.get("prompt", "")
            meta[name] = {
                "file": "inline (opencode.json)" if prompt else "inline",
                "desc": v.get("description", ""),
                "category": "orquestracao",
                "atype": v.get("mode", "agent"),
                "ver": "",
            }
            inline += 1

    order = ["orchestration", "academic", "research", "audit", "legal", "data",
             "inference", "engineering", "testing", "literary", "curation-agent",
             "integration", "mira-agent", "maswos-agent", "utility"]
    cats = {}
    for name, m in meta.items():
        cats.setdefault(m["category"], []).append(name)
    for k in list(cats):
        cats[k].sort(key=lambda n: n.lower())

    fd = []
    fd.append("% ============================================================")
    fd.append("%  MÓDULO 10 — Catálogo Completo de Agentes e Subagentes")
    fd.append("%  ARQUIVO GERADO — não editar à mão. Rode: python3 gen_mod10.py")
    fd.append("% ============================================================")
    fd.append("\\chapter{Catálogo Completo — Agentes e Subagentes (216)}")
    fd.append("")
    n_sub = sum(1 for v in cfg.get("agent", {}).values() if v.get("mode") != "primary")
    fd.append("\\begin{resultado}")
    fd.append(f"O \\pth{{opencode.json}} registra \\textbf{{216}} agentes "
              f"(1 orquestrador, {n_sub} subagentes), originados de \\textbf{{212}} "
              f"fichas em \\pth{{agents/catalog/}} e {inline} definições inline. "
              f"O catálogo abaixo é {meta and 'gerado determinísticamente por ' + 'gen\\_mod10.py'} "
              f"e agrupa as fichas por categoria.")
    fd.append("\\end{resultado}")
    fd.append("")
    fd.append("\\section{Panorama por categoria}")
    fd.append("")
    fd.append("\\begin{resultado}")
    fd.append("Contagem por categoria (ordem decrescente de fichas):\\par")
    fd.append("\\smallskip")
    fd.append("{\\footnotesize")
    fd.append("\\begin{tabularx}{\\textwidth}{lrX}")
    fd.append("\\toprule")
    fd.append("Categoria & Fichas & Exemplo de agentes \\\\")
    fd.append("\\midrule")
    for cat in sorted(cats, key=lambda c: -len(cats[c])):
        ex = ", ".join(cats[cat][:3])
        fd.append(f"{esc(cat)} & {len(cats[cat])} & {esc(ex)} \\\\")
    fd.append("\\bottomrule")
    fd.append("\\end{tabularx}\\par}")
    fd.append("\\end{resultado}")
    fd.append("")

    for cat in order:
        if cat not in cats:
            continue
        fd.append(r"\clearpage")
        fd.append(r"\section{Categoria: " + esc(cat.title()) + f" ({len(cats[cat])} agentes)" + "}")
        fd.append("")
        for name in cats[cat]:
            m = meta[name]
            ver = f" · v{m['ver']}" if m["ver"] else ""
            src = m["file"]
            fd.append(
                f"\\elemento{{{esc(name)} (v{m['ver']})}}"
                f"{{\\metainfo{{Categoria}}{{{esc(m['category'])}}} \\hfill "
                f"\\metainfo{{Tipo}}{{{esc(m['atype'])}}} \\hfill "
                f"\\metainfo{{Rota}}{{{esc(src)}}}}}"
            )
            fd.append("")
            fd.append("\\begin{descricao}")
            fd.append(esc(m["desc"]) or "\\_sem descrição\\_")
            fd.append("\\end{descricao}")
            fd.append("")
            if name in agents:
                perm = agents[name].get("permission", {})
                mode = agents[name].get("mode", "")
            else:
                perm, mode = {}, ""
            perm_txt = "; ".join(f"{k}: {v}" for k, v in perm.items())
            fd.append("\\begin{arquitetura}")
            fd.append("\\textbf{Modo:} " + esc(mode or "subagent")
                      + (" · \\textbf{Permissões:} " + esc(perm_txt) if perm_txt else ""))
            fd.append("\\end{arquitetura}")
            fd.append("")
    fd.append("% fim do módulo 10 (gerado)")

    open(OUT, "w", encoding="utf-8").write("\n".join(fd) + "\n")
    print(f"OK: {len(agents)} agentes -> {OUT} "
          f"({len([k for k in cats for _ in cats[k]])} fichas)")


if __name__ == "__main__":
    main()